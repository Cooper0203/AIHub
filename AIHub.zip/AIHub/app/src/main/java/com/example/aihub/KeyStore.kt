package com.example.aihub

import android.content.SharedPreferences

/** Several of your own API keys per provider, plus per-key cooldown timers. */
class KeyStore(private val p: SharedPreferences) {
    fun keys(id: String): List<String> =
        (p.getString("k_$id", "") ?: "").split("\n").map { it.trim() }.filter { it.isNotEmpty() }
    fun add(id: String, key: String) {
        val k = key.trim(); val l = keys(id)
        if (k.isNotEmpty() && k !in l) p.edit().putString("k_$id", (l + k).joinToString("\n")).apply()
    }
    fun remove(id: String, key: String) =
        p.edit().putString("k_$id", keys(id).filter { it != key }.joinToString("\n")).apply()
    fun isReady(key: String) = System.currentTimeMillis() >= p.getLong("c_${key.hashCode()}", 0L)
    fun cool(key: String, ms: Long) =
        p.edit().putLong("c_${key.hashCode()}", System.currentTimeMillis() + ms).apply()
    fun clearCooldowns() {
        val e = p.edit(); p.all.keys.filter { it.startsWith("c_") }.forEach { e.remove(it) }; e.apply()
    }
    fun mask(k: String) = if (k.length <= 8) "••••" else k.take(4) + "…" + k.takeLast(4)
}

class Attempt(val text: String?, val note: String)

object Dispatcher {
    private const val HOUR = 3_600_000L

    private fun hint(code: Int) = when (code) {
        401, 403 -> "key rejected (wrong key, or no access)"
        402 -> "no credit/balance on this account"
        404 -> "model name not found (edit it in Providers.kt)"
        400 -> "request rejected (often a wrong model name or bad key)"
        429 -> "rate limit or free credit used up"
        else -> "server error"
    }

    /** Tries each ready key of one provider; returns the answer or the real error reasons. */
    fun askProvider(p: Provider, prompt: String, store: KeyStore): Attempt {
        val keys = store.keys(p.id)
        if (keys.isEmpty()) return Attempt(null, "No key added.")
        val notes = mutableListOf<String>()
        for (k in keys) {
            val tag = store.mask(k)
            if (!store.isReady(k)) { notes += "$tag: cooling down (Setup > Reset cooldowns)"; continue }
            try { return Attempt(p.chat(prompt, k), "") }
            catch (e: HttpError) {
                notes += "$tag: HTTP ${e.code}, ${hint(e.code)}. ${e.message?.take(160)}"
                when (e.code) { 429, 402 -> store.cool(k, HOUR); 401, 403 -> store.cool(k, 24 * HOUR) }
            } catch (e: Exception) { notes += "$tag: ${e.javaClass.simpleName}: ${e.message}" }
        }
        return Attempt(null, notes.joinToString("\n"))
    }

    /** Walks providers in router order (free-first). Returns (title, text, success). */
    fun ask(prompt: String, store: KeyStore, order: List<Provider>): Triple<String, String, Boolean> {
        val fails = mutableListOf<String>()
        for (p in order) {
            val a = askProvider(p, prompt, store)
            if (a.text != null) return Triple(p.name, a.text, true)
            fails += "${p.name}: ${a.note}"
        }
        return Triple("No provider answered", fails.joinToString("\n\n"), false)
    }
}
