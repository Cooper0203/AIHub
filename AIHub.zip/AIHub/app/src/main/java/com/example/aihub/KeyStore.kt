package com.example.aihub

import android.content.SharedPreferences

/** Several of your own API keys per provider, plus per-key cooldown timers. */
class KeyStore(private val p: SharedPreferences) {
    fun keys(id: String): List<String> =
        (p.getString("k_$id", "") ?: "").split("\n").map { it.trim() }.filter { it.isNotEmpty() }
    fun add(id: String, key: String) {
        val k = key.trim(); val l = keys(id)
        if (k.isNotEmpty() && k !in l) p.edit().putString("k_$id", (l + k).joinToString("\n")).apply()
    }
    fun remove(id: String, key: String) =
        p.edit().putString("k_$id", keys(id).filter { it != key }.joinToString("\n")).apply()
    fun isReady(key: String) = System.currentTimeMillis() >= p.getLong("c_${key.hashCode()}", 0L)
    fun cool(key: String, ms: Long) =
        p.edit().putLong("c_${key.hashCode()}", System.currentTimeMillis() + ms).apply()
    fun mask(k: String) = if (k.length <= 8) "••••" else k.take(4) + "…" + k.takeLast(4)
}

object Dispatcher {
    private const val HOUR = 3_600_000L
    /** Tries each ready key of one provider. Rate-limited keys sleep 1h, bad keys 24h, others 5 min. */
    fun askProvider(p: Provider, prompt: String, store: KeyStore): String? {
        for (k in store.keys(p.id)) {
            if (!store.isReady(k)) continue
            try { return p.chat(prompt, k) }
            catch (e: HttpError) {
                store.cool(k, when (e.code) { 429, 402 -> HOUR; 401, 403 -> 24 * HOUR; else -> 300_000L })
            } catch (e: Exception) { store.cool(k, 300_000L) }
        }
        return null
    }
    /** Walks providers in router order (free-first) and returns the first answer. */
    fun ask(prompt: String, store: KeyStore, order: List<Provider>): Pair<String, String>? {
        for (p in order) askProvider(p, prompt, store)?.let { return p.name to it }
        return null
    }
}
