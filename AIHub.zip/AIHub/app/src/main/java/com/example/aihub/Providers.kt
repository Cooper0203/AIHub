package com.example.aihub

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** tier 0 = free, 1 = cheap, 2 = paid. Router tries lowest tier first (free-first). */
interface Provider {
    val id: String
    val name: String
    val tier: Int
    val strengths: Set<String>          // "code", "reasoning", "chat"
    fun chat(prompt: String, key: String): String   // blocking; call on Dispatchers.IO
}

fun httpPost(url: String, headers: Map<String, String>, body: String): String {
    val c = URL(url).openConnection() as HttpURLConnection
    c.requestMethod = "POST"
    c.connectTimeout = 15000
    c.readTimeout = 60000
    c.doOutput = true
    c.setRequestProperty("Content-Type", "application/json")
    headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
    c.outputStream.use { it.write(body.toByteArray()) }
    val ok = c.responseCode in 200..299
    val text = (if (ok) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
    if (!ok) error("HTTP ${c.responseCode}: ${text.take(200)}")
    return text
}

private fun msgs(prompt: String) =
    JSONArray().put(JSONObject().put("role", "user").put("content", prompt))

/** Works for OpenAI, DeepSeek, Grok, Groq (open-source models), OpenRouter, Together, etc. */
class OpenAICompat(
    override val id: String, override val name: String, override val tier: Int,
    override val strengths: Set<String>, private val baseUrl: String, private val model: String
) : Provider {
    override fun chat(prompt: String, key: String): String {
        val body = JSONObject().put("model", model).put("messages", msgs(prompt)).toString()
        val r = httpPost("$baseUrl/chat/completions", mapOf("Authorization" to "Bearer $key"), body)
        return JSONObject(r).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content")
    }
}

class AnthropicProvider(private val model: String) : Provider {
    override val id = "claude"; override val name = "Claude"; override val tier = 2
    override val strengths = setOf("code", "reasoning")
    override fun chat(prompt: String, key: String): String {
        val body = JSONObject().put("model", model).put("max_tokens", 1024)
            .put("messages", msgs(prompt)).toString()
        val r = httpPost("https://api.anthropic.com/v1/messages",
            mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), body)
        return JSONObject(r).getJSONArray("content").getJSONObject(0).getString("text")
    }
}

class GeminiProvider(private val model: String) : Provider {
    override val id = "gemini"; override val name = "Gemini"; override val tier = 0
    override val strengths = setOf("chat", "reasoning")
    override fun chat(prompt: String, key: String): String {
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts",
            JSONArray().put(JSONObject().put("text", prompt))))).toString()
        val r = httpPost("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$key",
            emptyMap(), body)
        return JSONObject(r).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
    }
}

object Providers {
    // Model names change often: edit them here. To add a provider, add one line.
    val all: List<Provider> = listOf(
        GeminiProvider("gemini-flash-latest"),                                   // free tier
        OpenAICompat("groq", "Open-source (Groq)", 0, setOf("chat", "code"),
            "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile"),         // free tier
        OpenAICompat("deepseek", "DeepSeek", 1, setOf("code", "reasoning"),
            "https://api.deepseek.com/v1", "deepseek-chat"),
        OpenAICompat("openai", "ChatGPT", 2, setOf("chat", "code"),
            "https://api.openai.com/v1", "gpt-4o-mini"),
        AnthropicProvider("claude-haiku-5-5"),
        OpenAICompat("grok", "Grok", 2, setOf("chat", "reasoning"),
            "https://api.x.ai/v1", "grok-3-mini"),
    )
}

object Router {
    fun classify(p: String): String {
        val s = p.lowercase()
        return when {
            listOf("code", "function", "bug", "kotlin", "python", "sql", "error", "```").any { it in s } -> "code"
            p.length > 400 || listOf("why", "explain", "prove", "step by step", "compare").any { it in s } -> "reasoning"
            else -> "chat"
        }
    }
    /** Free-first: lowest tier first; within a tier, providers strong at the task go first. */
    fun order(prompt: String, available: List<Provider>): List<Provider> {
        val task = classify(prompt)
        return available.sortedWith(compareBy({ it.tier }, { if (task in it.strengths) 0 else 1 }))
    }
}
