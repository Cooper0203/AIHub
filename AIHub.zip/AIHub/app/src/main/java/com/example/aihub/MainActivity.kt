package com.example.aihub

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("keys", MODE_PRIVATE)
        val store = KeyStore(prefs)
        if (!prefs.getBoolean("reset_v3", false)) { store.clearCooldowns(); prefs.edit().putBoolean("reset_v3", true).apply() }
        setContent { MaterialTheme { Surface { App(store) } } }
    }
}

@Composable
fun App(store: KeyStore) {
    var prompt by remember { mutableStateOf("") }
    var compare by remember { mutableStateOf(false) }
    var showSetup by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var tick by remember { mutableStateOf(0) }
    var results by remember { mutableStateOf(listOf<Pair<String, String>>()) }
    val scope = rememberCoroutineScope()

    fun run() {
        val avail = Providers.all.filter { store.keys(it.id).isNotEmpty() }
        if (avail.isEmpty()) { results = listOf("Setup" to "Tap Setup and add at least one API key."); return }
        busy = true; results = emptyList()
        scope.launch {
            if (compare) {
                results = avail.map { p ->
                    async(Dispatchers.IO) {
                        val a = Dispatcher.askProvider(p, prompt, store)
                        p.name to (a.text ?: ("Failed:\n" + a.note))
                    }
                }.awaitAll()
            } else {
                val out = withContext(Dispatchers.IO) { Dispatcher.ask(prompt, store, Router.order(prompt, avail)) }
                results = listOf((if (out.third) "${out.first} (auto-routed)" else out.first) to out.second)
            }
            tick++; busy = false
        }
    }

    Column(Modifier.fillMaxSize().systemBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("AI Hub", style = MaterialTheme.typography.headlineSmall)
            TextButton(onClick = { showSetup = true }) { Text("Setup") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = compare, onCheckedChange = { compare = it })
            Spacer(Modifier.width(8.dp))
            Text(if (compare) "Compare all providers" else "Auto: best free-first answer")
        }
        OutlinedTextField(prompt, { prompt = it }, Modifier.fillMaxWidth(), label = { Text("Ask anything") }, minLines = 2)
        Button(onClick = { run() }, enabled = !busy && prompt.isNotBlank()) { Text(if (busy) "Thinking..." else "Send") }
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            results.forEach { (who, text) ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(who, style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(4.dp))
                        SelectionContainer { Text(text) }
                    }
                }
            }
        }
    }

    if (showSetup) {
        val ctx = LocalContext.current
        val clip = LocalClipboardManager.current
        val uri = LocalUriHandler.current
        AlertDialog(
            onDismissRequest = { showSetup = false },
            confirmButton = { TextButton(onClick = { showSetup = false }) { Text("Done") } },
            title = { Text("Setup: your API keys") },
            text = {
                val refresh = tick
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text("Tap Get key, create your key on the site, copy it, come back and tap Paste. You can paste several keys per provider.",
                        style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = { store.clearCooldowns(); tick++ }) { Text("Reset cooldowns") }
                    Providers.all.forEach { p ->
                        Spacer(Modifier.height(12.dp))
                        Text(p.name + if (p.tier == 0) "  (free tier)" else "", style = MaterialTheme.typography.titleSmall)
                        Row {
                            TextButton(onClick = { uri.openUri(p.keyUrl) }) { Text("Get key") }
                            TextButton(onClick = {
                                val t = clip.getText()?.text?.trim() ?: ""
                                if (t.length >= 20 && !t.contains(" ")) { store.add(p.id, t); tick++ }
                                else Toast.makeText(ctx, "Copy your API key first", Toast.LENGTH_SHORT).show()
                            }) { Text("Paste") }
                        }
                        store.keys(p.id).forEach { k ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(store.mask(k) + if (!store.isReady(k)) "  (cooling down)" else "", Modifier.weight(1f))
                                TextButton(onClick = { store.remove(p.id, k); tick++ }) { Text("Remove") }
                            }
                        }
                    }
                }
            })
    }
}
