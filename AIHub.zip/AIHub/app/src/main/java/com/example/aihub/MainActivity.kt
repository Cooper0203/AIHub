package com.example.aihub

import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("keys", MODE_PRIVATE)
        setContent { MaterialTheme { Surface { App(prefs) } } }
    }
}

@Composable
fun App(prefs: SharedPreferences) {
    var prompt by remember { mutableStateOf("") }
    var compare by remember { mutableStateOf(false) }
    var showKeys by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf(listOf<Pair<String, String>>()) }
    val scope = rememberCoroutineScope()
    fun key(p: Provider) = prefs.getString(p.id, "") ?: ""

    fun run() {
        val avail = Providers.all.filter { key(it).isNotBlank() }
        if (avail.isEmpty()) { results = listOf("Setup" to "Tap Keys and add at least one API key."); return }
        busy = true; results = emptyList()
        scope.launch {
            if (compare) {
                results = avail.map { p ->
                    async(Dispatchers.IO) {
                        p.name to runCatching { p.chat(prompt, key(p)) }.getOrElse { "Error: ${it.message}" }
                    }
                }.awaitAll()
            } else {
                var out: Pair<String, String>? = null
                for (p in Router.order(prompt, avail)) {
                    try {
                        val r = withContext(Dispatchers.IO) { p.chat(prompt, key(p)) }
                        out = "${p.name} (auto-routed)" to r; break
                    } catch (_: Exception) { /* fall through to next provider */ }
                }
                results = listOf(out ?: ("All providers failed" to "Check keys, quota and network."))
            }
            busy = false
        }
    }

    Column(Modifier.fillMaxSize().systemBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("AI Hub", style = MaterialTheme.typography.headlineSmall)
            TextButton(onClick = { showKeys = true }) { Text("Keys") }
        }
        Row {
            Switch(checked = compare, onCheckedChange = { compare = it })
            Spacer(Modifier.width(8.dp))
            Text(if (compare) "Compare all providers" else "Auto: best free-first answer")
        }
        OutlinedTextField(prompt, { prompt = it }, Modifier.fillMaxWidth(), label = { Text("Ask anything") }, minLines = 2)
        Button(onClick = { run() }, enabled = !busy && prompt.isNotBlank()) { Text(if (busy) "Thinking..." else "Send") }
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            results.forEach { (who, text) ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(who, style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(4.dp))
                        SelectionContainer { Text(text) }
                    }
                }
            }
        }
    }

    if (showKeys) AlertDialog(
        onDismissRequest = { showKeys = false },
        confirmButton = { TextButton(onClick = { showKeys = false }) { Text("Done") } },
        title = { Text("API keys (stay on this device)") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Providers.all.forEach { p ->
                    var v by remember { mutableStateOf(key(p)) }
                    OutlinedTextField(v, { v = it; prefs.edit().putString(p.id, it.trim()).apply() },
                        Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        label = { Text(p.name + if (p.tier == 0) " (free tier)" else "") }, singleLine = true)
                }
            }
        })
}
