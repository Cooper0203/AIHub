# AI Hub: Architecture & Implementation Plan

## 1. Goals
Android app that sends one prompt to many AI providers. Distribution is automatic,
usage is free-first, output is both a single routed answer and a side-by-side compare.

## 2. Architecture (client-only v1)
UI (Jetpack Compose) -> Router -> Provider adapters -> provider REST APIs
- UI: prompt box, Auto/Compare switch, key manager, result cards.
- Router: classifies prompt (code / reasoning / chat), filters providers that have
  a key, sorts by cost tier (0 free, 1 cheap, 2 paid), then by task strength.
  On error/quota it falls through to the next provider (automatic failover).
- Provider adapters: one interface (id, name, tier, strengths, chat()).
  OpenAICompat covers ChatGPT, DeepSeek, Grok, Groq/OpenRouter/Together (open-source models).
  AnthropicProvider (Claude) and GeminiProvider have their own request formats.
- Key storage: SharedPreferences (v1), user brings own keys.

## 3. Output modes
- Auto: first successful provider in router order, labelled with who answered.
- Compare: all keyed providers in parallel (coroutines async), one card each.

## 4. Free-first policy
Tier 0: Gemini (free API tier), Groq-hosted open-source models (free tier).
Tier 1: DeepSeek (very cheap). Tier 2: ChatGPT, Claude, Grok (paid).
Paid providers are only used when free ones fail or are absent, or in Compare mode.

## 5. Adding providers
Add one line in Providers.all (OpenAICompat for any OpenAI-style API).

## 6. Roadmap
1. v1 (this repo): single-turn chat, routing, failover, compare, local keys.
2. v2: conversation history (Room), streaming (SSE), markdown rendering, per-provider
   model picker, usage counters / daily free-quota tracking.
3. v3: EncryptedSharedPreferences/Keystore, smarter routing (LLM-based classifier,
   latency + error-rate scoring), image input, settings screen.
4. v4: optional backend proxy (Cloudflare Worker / small server) so keys are not on
   devices, accounts, rate limiting, Play Store release with a signed release build.

## 7. Building the APK
GitHub: create a repo, upload all files (keep .github/ folder), open the Actions tab,
run "Build APK", download artifact AIHub-debug-apk (app-debug.apk), install on phone.
Code On The Go: open the project folder and run assembleDebug (Gradle 8.7, JDK 17).
The APK appears in app/build/outputs/apk/debug/.
